import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "../models/User.js";

dotenv.config();

const setupAdmin = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected to MongoDB");

    const adminEmail = 'admin@college.edu';
    const adminPassword = 'admin123';

    // Check if admin already exists
    const existingAdmin = await User.findOne({ email: adminEmail });
    
    if (existingAdmin) {
      console.log(`✅ Admin account already exists: ${adminEmail}`);
      console.log(`   Email: ${existingAdmin.email}`);
      console.log(`   Role: ${existingAdmin.role}`);
      console.log(`\n💡 To reset admin password, delete the admin account and run this script again.`);
      console.log(`\n   Or use: db.users.deleteOne({ email: 'admin@college.edu' })`);
      
      // Optionally update the admin to ensure role is correct
      if (existingAdmin.role !== 'admin') {
        existingAdmin.role = 'admin';
        await existingAdmin.save();
        console.log(`\n✅ Updated admin role to 'admin'`);
      }
    } else {
      // Create admin account
      const admin = await User.create({
        email: adminEmail,
        passwordHash: adminPassword,
        campusId: 'ADMIN-001',
        role: 'admin',
        points: 0
      });

      console.log(`✅ Admin account created successfully!`);
      console.log(`   Email: ${admin.email}`);
      console.log(`   Password: ${adminPassword}`);
      console.log(`   Role: ${admin.role}`);
    }

    console.log('\n✅ Setup complete!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
};

setupAdmin();
