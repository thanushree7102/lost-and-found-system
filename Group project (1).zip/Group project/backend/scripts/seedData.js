import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "../models/User.js";
import Item from "../models/Item.js";
import Claim from "../models/Claim.js";
import bcrypt from "bcryptjs";

dotenv.config();

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected to MongoDB");

    // Clear existing data
    await User.deleteMany({});
    await Item.deleteMany({});
    await Claim.deleteMany({});
    console.log("Cleared existing data");

    // Create sample users
    const passwordHash = await bcrypt.hash("password123", 10);
    
    const adminUser = await User.create({
      campusId: "ADMIN-001",
      email: "admin@college.edu",
      role: "admin",
      passwordHash: passwordHash,
      points: 0,
    });

    const student1 = await User.create({
      campusId: "STU-2024-001",
      email: "john@college.edu",
      role: "student",
      passwordHash: passwordHash,
      points: 850,
    });

    const student2 = await User.create({
      campusId: "STU-2024-002",
      email: "sarah@college.edu",
      role: "student",
      passwordHash: passwordHash,
      points: 650,
    });

    console.log("Created users:", adminUser.email, student1.email, student2.email);

    // Create sample items
    const item1 = await Item.create({
      title: "Black Wireless Headphones",
      description: "Sony brand, slight scratch on left ear cup. Found in library.",
      category: "Electronics",
      dateFound: new Date("2024-12-01"),
      generalArea: "Central Library",
      hiddenLocation: "Library, 2nd Floor, Table 4",
      status: "active",
      finderId: student1._id,
    });

    const item2 = await Item.create({
      title: "Blue Water Bottle",
      description: "Metal bottle with a sticker of a cat. Found in cafeteria.",
      category: "Other",
      dateFound: new Date("2024-12-02"),
      generalArea: "Cafeteria",
      hiddenLocation: "Cafeteria, Table 12",
      status: "active",
      finderId: student2._id,
    });

    const item3 = await Item.create({
      title: "Silver Car Key",
      description: "Silver car key with a Honda logo. Found in parking lot.",
      category: "Keys",
      dateFound: new Date("2024-12-03"),
      generalArea: "Parking Lot",
      hiddenLocation: "Parking Lot, Section B",
      status: "at_desk",
      finderId: student1._id,
      pickupCode: "PICK-099-SECURE",
    });

    console.log("Created items:", item1.title, item2.title, item3.title);

    // Create sample claim
    const answerHash = await bcrypt.hash("Library second floor", 10);
    const claim1 = await Claim.create({
      itemId: item1._id,
      ownerId: student2._id,
      answerHash: answerHash,
      status: "pending",
    });

    console.log("Created claim for:", item1.title);

    console.log("\n✅ Sample data created successfully!");
    console.log("\nSummary:");
    console.log(`- Users: ${await User.countDocuments()}`);
    console.log(`- Items: ${await Item.countDocuments()}`);
    console.log(`- Claims: ${await Claim.countDocuments()}`);
    console.log("\nYou can now view this data in MongoDB Compass!");

    process.exit(0);
  } catch (error) {
    console.error("Error seeding data:", error);
    process.exit(1);
  }
};

seedData();

