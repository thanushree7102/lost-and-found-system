import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  campusId: String,
  email: String,
  role: { type: String, default: "student" },
  passwordHash: String,
  points: { type: Number, default: 0 },
});

export default mongoose.model("User", userSchema);

