import mongoose from "mongoose";

const claimSchema = new mongoose.Schema({
  itemId: { type: mongoose.Schema.Types.ObjectId, ref: "Item" },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  answerHash: String,
  status: { type: String, default: "pending" },
  pickupCodeIssued: String,
}, { timestamps: true });

export default mongoose.model("Claim", claimSchema);

