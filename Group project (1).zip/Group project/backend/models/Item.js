import mongoose from "mongoose";

const itemSchema = new mongoose.Schema({
  title: String,
  description: String,
  category: String,
  type: { type: String, enum: ['found', 'lost'], default: 'found' }, // 'found' or 'lost'
  dateFound: Date,
  dateLost: Date,
  generalArea: String,
  locationLost: String, // For lost items
  hiddenLocation: String,
  gps: {
    lat: Number,
    lng: Number,
  },
  imageHash: String,
  status: { type: String, default: "active" },
  finderId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  pickupCode: String,
}, { timestamps: true });

itemSchema.index({ title: "text", description: "text" });

export default mongoose.model("Item", itemSchema);

