import express from "express";
import { protect, adminOnly } from "../middleware/auth.js";
import { createClaim, approveClaim } from "../controllers/claimController.js";

const router = express.Router();

router.post("/", protect, createClaim);
router.put("/:id/approve", protect, adminOnly, approveClaim);

export default router;

