import express from "express";
import { protect, adminOnly } from "../middleware/auth.js";
import {
  getAllData,
  getUsers,
  getItems,
  getClaims,
  viewAllDataPublic,
} from "../controllers/adminController.js";

const router = express.Router();

// Public route for easy data viewing (development only)
router.get("/view", viewAllDataPublic);

// All routes require admin authentication
router.get("/all", protect, adminOnly, getAllData);
router.get("/users", protect, adminOnly, getUsers);
router.get("/items", protect, adminOnly, getItems);
router.get("/claims", protect, adminOnly, getClaims);

export default router;

