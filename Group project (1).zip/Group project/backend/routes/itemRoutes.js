import express from "express";
import { protect, adminOnly } from "../middleware/auth.js";
import { createItem, searchItems, updateStatus, deleteAllItems } from "../controllers/itemController.js";

const router = express.Router();

router.post("/", protect, createItem);
router.get("/search", searchItems);
router.put("/:id/status", protect, adminOnly, updateStatus);
// Admin-only bulk delete (remove all items)
router.delete("/", protect, adminOnly, deleteAllItems);

export default router;

