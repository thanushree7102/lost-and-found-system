import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

export const registerUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Simple validation - just check if email contains @
    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: "Invalid email format" });
    }

    if (!password || password.length < 3) {
      return res.status(400).json({ error: "Password must be at least 3 characters" });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    // Save password directly (no hashing for simplicity)
    const user = await User.create({
      email,
      passwordHash: password, // Storing password directly
      campusId: email.split('@')[0],
      role: "student",
    });

    res.json({ success: true, user: { _id: user._id, email: user.email, role: user.role } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Simple validation
    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: "Invalid email format" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Simple password check (direct comparison)
    if (user.passwordHash !== password) {
      return res.status(401).json({ error: "Wrong password" });
    }

    // Generate token
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({ 
      token, 
      user: {
        _id: user._id,
        email: user.email,
        role: user.role,
        campusId: user.campusId,
        points: user.points || 0
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

