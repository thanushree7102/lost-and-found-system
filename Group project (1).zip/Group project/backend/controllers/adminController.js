import User from "../models/User.js";
import Item from "../models/Item.js";
import Claim from "../models/Claim.js";

export const getAllData = async (req, res) => {
  try {
    const users = await User.find().select("-passwordHash");
    const items = await Item.find().populate("finderId", "campusId email");
    const claims = await Claim.find()
      .populate("itemId", "title description")
      .populate("ownerId", "campusId email");

    res.json({
      users: users,
      items: items,
      claims: claims,
      summary: {
        totalUsers: users.length,
        totalItems: items.length,
        totalClaims: claims.length,
        activeItems: items.filter(i => i.status === "active").length,
        pendingClaims: claims.filter(c => c.status === "pending").length,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getUsers = async (req, res) => {
  try {
    const users = await User.find().select("-passwordHash");
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getItems = async (req, res) => {
  try {
    const items = await Item.find().populate("finderId", "campusId email");
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getClaims = async (req, res) => {
  try {
    const claims = await Claim.find()
      .populate("itemId", "title description")
      .populate("ownerId", "campusId email");
    res.json(claims);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Public endpoint to view data (for development - remove auth for easy access)
export const viewAllDataPublic = async (req, res) => {
  try {
    const users = await User.find().select("-passwordHash");
    const items = await Item.find().populate("finderId", "campusId email");
    const claims = await Claim.find()
      .populate("itemId", "title description")
      .populate("ownerId", "campusId email");

    res.json({
      users: users,
      items: items,
      claims: claims,
      summary: {
        totalUsers: users.length,
        totalItems: items.length,
        totalClaims: claims.length,
        activeItems: items.filter(i => i.status === "active").length,
        pendingClaims: claims.filter(c => c.status === "pending").length,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
