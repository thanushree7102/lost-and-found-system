import Claim from "../models/Claim.js";
import bcrypt from "bcryptjs";
import Item from "../models/Item.js";

export const createClaim = async (req, res) => {
  const { itemId, answer } = req.body;

  const hash = await bcrypt.hash(answer, 10);

  const claim = await Claim.create({
    itemId,
    ownerId: req.user.id,
    answerHash: hash,
  });

  res.json(claim);
};

export const approveClaim = async (req, res) => {
  const pickupCode = Math.floor(100000 + Math.random() * 900000).toString();

  const claim = await Claim.findByIdAndUpdate(
    req.params.id,
    { status: "approved", pickupCodeIssued: pickupCode },
    { new: true }
  );

  await Item.findByIdAndUpdate(claim.itemId, { pickupCode });

  res.json(claim);
};

