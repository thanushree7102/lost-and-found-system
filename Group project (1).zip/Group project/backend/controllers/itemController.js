import Item from "../models/Item.js";

export const createItem = async (req, res) => {
  const item = await Item.create({ ...req.body, finderId: req.user.id });
  res.json(item);
};

export const searchItems = async (req, res) => {
  const { text, area, category } = req.query;

  const query = {};

  if (area) query.generalArea = area;
  if (category) query.category = category;

  let items = await Item.find(query);

  if (text) {
    items = await Item.find({
      $text: { $search: text }
    });
  }

  res.json(items);
};

export const updateStatus = async (req, res) => {
  const item = await Item.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true }
  );
  res.json(item);
};

export const deleteAllItems = async (req, res) => {
  // Admin-only bulk delete
  try {
    const result = await Item.deleteMany({});
    return res.json({ deletedCount: result.deletedCount });
  } catch (err) {
    console.error('Failed to delete all items:', err);
    return res.status(500).json({ message: 'Failed to delete items' });
  }
};

